#-*- coding:utf-8 -*-
from PIL import Image, ImageFont, ImageDraw
import argparse
import os
import imageio

#命令行输入参数处理
parser = argparse.ArgumentParser()
parser.add_argument('png')
#获取参数
args = parser.parse_args()
png = args.png

codeLib = '''@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~<>i!lI;:,"^`'. '''#生成字符画所需的字符集
count = len(codeLib)

def transform1(image_file, txt_png):
    image_file = image_file.convert("L")#转换为黑白图片，参数"L"表示黑白模式
    codePic = ''
    for h in range(0,image_file.size[1]):  #size属性表示图片的分辨率，'0'为横向大小，'1'为纵向
        for w in range(0,image_file.size[0]):
            gray = image_file.getpixel((w,h)) #返回指定位置的像素，如果所打开的图像是多层次的图片，那这个方法就返回一个元组
            codePic = codePic + codeLib[int(((count-1)*gray)/256)]#建立灰度与字符集的映射
        codePic = codePic+'\r\n'

    # 创建图片
    im_txt = Image.new("RGB",(image_file.size[1]*5,image_file.size[0]*6),(255,255,255))
    dr = ImageDraw.Draw(im_txt)
    font=ImageFont.load_default().font
    x=y=0
    font_w,font_h=font.getsize(codePic[1])    #获取字体的宽高
    font_w = font_w * 0.6
    font_h = font_h * 0.6
    for i in range(len(codePic)):
        if(codePic[i]=='\n'):
            x+=font_h
            y=-font_w
        dr.text([y,x],codePic[i],(0, 0, 0))
        y+=font_w
    im_txt.save(txt_png)
    return codePic


def png2txtAndtxtpng(name, txt, txt_png):
    fp = open(name,'rb')
    image_file = Image.open(fp)
    image_file=image_file.resize((int(image_file.size[0]*0.75), int(image_file.size[1]*0.5)))
    tmp = open(txt,'w')
    tmp.write(transform1(image_file, txt_png))
    tmp.close()

if __name__=='__main__':
    txt = png.split('.')[0] + '.txt'
    txt_png = png.split('.')[0] + '-txt.png'
    png2txtAndtxtpng(png,txt, txt_png)
    