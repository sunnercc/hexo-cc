# Duck
这是一只神奇的鸭子

## gif2txt_gif.py
gif转多个png文件，多个txt文件，多个txt_png文件

``` bash
$ gif2txt_gif duck.gif
```

## png2txt_png.py
png转txt_png文件

``` bash
$ png2txt_png duck.png
```

## 神奇的鸭子
[字符画鸭子](https://github.com/sunnercc/Duck/blob/master/create.gif)
