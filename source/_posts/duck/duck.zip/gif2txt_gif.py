# -*- coding: utf-8 -*-
from PIL import Image, ImageDraw, ImageFont
import argparse
import os
import imageio
#命令行输入参数处理
parser = argparse.ArgumentParser()
parser.add_argument('gif')
#获取参数
args = parser.parse_args()
gif = args.gif

codeLib = '''@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~<>i!lI;:,"^`'. '''#生成字符画所需的字符集
count = len(codeLib)
global gif2png_count

def transform1(image_file, txt_png):
    image_file = image_file.convert("L")#转换为黑白图片，参数"L"表示黑白模式
    codePic = ''
    for h in range(0,image_file.size[1]):  #size属性表示图片的分辨率，'0'为横向大小，'1'为纵向
        for w in range(0,image_file.size[0]):
            gray = image_file.getpixel((w,h)) #返回指定位置的像素，如果所打开的图像是多层次的图片，那这个方法就返回一个元组
            codePic = codePic + codeLib[int(((count-1)*gray)/256)]#建立灰度与字符集的映射
        codePic = codePic+'\r\n'

    # 创建图片
    im_txt = Image.new("RGB",(image_file.size[1]*5,image_file.size[0]*6),(255,255,255))
    dr = ImageDraw.Draw(im_txt)
    font=ImageFont.load_default().font
    x=y=0
    font_w,font_h=font.getsize(codePic[1])    #获取字体的宽高
    font_w = font_w * 0.6
    font_h = font_h * 0.6
    for i in range(len(codePic)):
        if(codePic[i]=='\n'):
            x+=font_h
            y=-font_w
        dr.text([y,x],codePic[i],(0, 0, 0))
        y+=font_w
    im_txt.save(txt_png)
    return codePic

#拆分gif
def gif2png(gif):
    im = Image.open(gif)
    path = os.getcwd()
    if(not os.path.exists(path+"/Cache")):
        os.mkdir(path+"/Cache")
    os.chdir(path+"/Cache")
    global gif2png_count
    gif2png_count = 0
    try:
        while 1:
            current = im.tell()
            name = gif.split('.')[0]+'-'+str(current)+'.png'
            im.save(name)

            # # png 转化为 txt
            txt = gif.split('.')[0]+'-'+str(current)+'.txt'
            txt_png = gif.split('.')[0]+'-'+str(current)+'-txt.png'
            png2txtAndtxtpng(name, txt, txt_png)
            print(name)
            print(txt)
            print(txt_png)
            im.seek(current+1)
            gif2png_count = gif2png_count + 1

    except:
        os.chdir(path)


def png2txtAndtxtpng(name, txt, txt_png):
    fp = open(name,'rb')
    image_file = Image.open(fp)
    image_file=image_file.resize((int(image_file.size[0]*0.75), int(image_file.size[1]*0.5)))
    tmp = open(txt,'w')
    tmp.write(transform1(image_file, txt_png))
    tmp.close()
 


def create_gif(image_list, gif_name):
 
    frames = []
    for image_name in image_list:
        frames.append(imageio.imread(image_name))
    # Save them as frames into a gif 
    imageio.mimsave(gif_name, frames, 'GIF', duration = 0.1)
    return
 
def png2gif(dir_name):
    image_list = []
    for i in range(0,gif2png_count):
        path = dir_name + '/' + gif.split('.')[0] + '-' + str(i) + "-txt.png"
        print(path)
        image_list.append(path)

    create_gif(image_list, "create.gif")


def run(gif):
    gif2png(gif)
    path = os.getcwd()
    png2gif(path+"/Cache")

if __name__=='__main__':
    run(gif)
    

